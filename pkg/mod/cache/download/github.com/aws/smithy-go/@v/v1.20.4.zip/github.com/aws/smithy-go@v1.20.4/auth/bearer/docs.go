// Package bearer provides middleware and utilities for authenticating API
// operation calls with a Bearer Token.
package bearer
